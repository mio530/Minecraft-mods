say [DNA] Fertig.
